package com.example.cat1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    private TextView dateTimeDisplay;
    private TextView format1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String dateTime;
        Calendar calendar;
        SimpleDateFormat simpleDateFormat;
        format1 = (TextView) findViewById(R.id.dateview);
        calendar = Calendar.getInstance();
        simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss aaa z");
        dateTime = simpleDateFormat.format(calendar.getTime()).toString();
        format1.setText(dateTime);
    }
    public void toreg(View view)
    {
        Intent i=new Intent(MainActivity.this,RegisterActivity.class);
        startActivity(i);
    }
    public void togallery(View view)
    {
        Intent i=new Intent(MainActivity.this,gallery.class);
        startActivity(i);
    }
    public void toanbout(View view)
    {
        Intent i=new Intent(MainActivity.this,about.class);
        startActivity(i);
    }
}