package com.example.cat1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    Button reg;
    EditText name, phn, mail, cname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        reg = findViewById(R.id.button);
        name = findViewById(R.id.name);
        phn = findViewById(R.id.editTextPhone);
        mail = findViewById(R.id.editTextTextEmailAddress);
        cname = findViewById(R.id.college);


        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new

                        AlertDialog.Builder(RegisterActivity.this);

                alertDialogBuilder.setMessage("Confirm registeration?");
                alertDialogBuilder.setPositiveButton("yes",
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface arg0, int arg1) {

                                Toast.makeText(RegisterActivity.this, "Registered Sucessfully\n" + "Name: " + name + "\nCollege: " + cname + "\nPhone Numbner" + phn + "\nEmail" + mail.getText(), Toast.LENGTH_LONG).show();
                                Intent i=new Intent(RegisterActivity.this,thankyou.class);
                                startActivity(i);
                            }
                        });

                alertDialogBuilder.setNegativeButton("No", new

                        DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        });
                AlertDialog alertDialog = alertDialogBuilder.create();
                alertDialog.show();
            }

        });

    }
}